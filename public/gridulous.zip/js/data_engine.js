var DataEngine = Class.$extend({
  __init__: function(grid_configuration) {
    this.configuration = grid_configuration;

  }


});
